Installation:

1. Move solar-system.widget to your widgets folder
2. Open index.coffee (TextEdit will work)
3. On the second line, make sure to change "USER" to your username/homefolder
4. Save and close
5. Enjoy!

Customization:

1. Open index.coffee (TextEdit will work)
2. The first 50 or so lines contain all customizable values
3. Commented lines describe each value and their default setting
4. Adjust what you please
5. Make sure to preserve the "#Default" lines so you can reset things in case you make a mistake!
6. Editing anything under the "DO NOT edit anything below this unless you know what you're doing!!!" line most likely will break the widget, so DO NOT mess around down there unless you know what you're doing!!!
7. You can add your own images for the planets. Just add your desired picture to the solar-system.widget folder and change the name to overwrite whatever image you'd like to replace